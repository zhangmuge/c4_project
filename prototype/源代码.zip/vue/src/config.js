export default {
    Ryu_URL:'/api',
    Mini_URL:'/topo'
//    这里仍然是用代理，代理文件在vue.config.js
}