<template>
<div class="container-fluid">
<!--  操作面板默认显示-->
  <h4>请在上方面板选择操作</h4>
</div>
</template>

<script>
export default {
  name: "default_route"
}
</script>

<style scoped>

</style>