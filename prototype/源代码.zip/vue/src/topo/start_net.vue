<template>
<div class="container-fluid">
<!--  这里和default_topo的组件差不多，方法写在了App.vue，此处只显示状态-->
  拓扑搭建成功，连接Ryu成功，转入Ryu操作面板
</div>
</template>

<script>
export default {
  name: "start_net"
}
</script>

<style scoped>

</style>