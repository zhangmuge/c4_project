<template>
  <iframe width="1000px" height="700px" src="http://127.0.0.1:8080/" scrolling="yes"></iframe>
<!--  iframe用于在网页中嵌入另一个网页，这里直接调用ryu的拓扑web即可-->
</template>

<script>
export default {
  name: "watchtopo"
}
</script>

<style scoped>

</style>